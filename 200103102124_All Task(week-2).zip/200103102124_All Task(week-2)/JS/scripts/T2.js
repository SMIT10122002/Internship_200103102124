function showContent(){
    document.getElementById('text').innerHTML='Hey! This is me..';
  }
  function hideContent(){
    document.getElementById('text').innerHTML='';
  }
  function smallcontent(){
    document.getElementById('text').style.fontSize='20px';
  }
  function mediumcontent(){
    document.getElementById('text').style.fontSize='40px';
  }
  function largecontent(){
    document.getElementById('text').style.fontSize='60px';
  }